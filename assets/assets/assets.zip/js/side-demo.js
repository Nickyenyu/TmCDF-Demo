(function() {

	"use strict";
	$('.side-demo').on("click", function() {
		$('.demo-page-landing').toggleClass("active");
	});
})();